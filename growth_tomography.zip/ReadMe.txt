Evolution of the $f\sigma_8$ tension with the $Planck15$-$\Lambda$CDM determination and implications for modified gravity theories.

The Mathematica file "Growth Tomography" contains the code as well as comments that produce all the figures  of the paper.  All figures were produced with 
"Wolfram Mathematica 11.0".

If you use any of the above codes or the figures in a published work please cite the paper.

Any further questions/comments are welcome.

Lavrentios Kazantzidis <lkazantzi@cc.uoi.gr>
Leandros Perivolaropoulos <leandros@uoi.gr>